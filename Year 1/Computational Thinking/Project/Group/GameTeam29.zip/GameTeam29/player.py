from map import *
from items import *

# Current_city is the city the user is currently in
current_city = cardiff

# Current_Place is the location of the user in a city
current_place = None
equipped_weapon = None
equipped_armour = None

# health_item_template, defence_buff_item, damage_buff_item

inventory = []

# Not including equipped items
max_inventory_items = 4